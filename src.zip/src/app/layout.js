// 1. TOKENS - Design tokens (OKLCH colors, surfaces, gradients, accent veils)
import '@/styles/tokens/theme.css'

// 2. PRIMITIVES - Layout primitives and component primitives (stack, cluster, grid, button)
import '@/styles/primitives/index.css'

// 3. UTILITIES - Section presets and layout utilities (@layer utilities)
import '@/styles/system/section-presets.css'
import '@/styles/system/layout.css'

// 4. GLOBALS - Base styles
import '@/styles/globals.css'

// 5. COMPONENTS - Component-specific styles (@layer components)
import '@/styles/components/buttons.css'
import '@/styles/components/section.css'
import '@/styles/components/section.variants.css'
import '@/styles/components/section.wrapper.css'
import '@/styles/components/navbar.css'
import '@/styles/components/hero.css'
import '@/styles/components/experience.css'
import '@/styles/components/spaces.css'
import '@/styles/components/gallery.css'
import '@/styles/components/alternating-blocks.css'
import '@/styles/components/brand-proof.css'
import '@/styles/components/pricing.css'
import '@/styles/components/schedule-form.css'
import '@/styles/components/map.css'
import '@/styles/components/footer.css'
import '@/styles/components/faq.css'
import '@/styles/components/section.legacy-wrapper.css'

import StoryblokProvider from '@/components/StoryblokProvider';
import { ThemeProvider } from '@/components/ui/ThemeProvider';
import { playfairDisplay, montserrat, dancingScript } from './fonts';
import Navbar from '@/components/clean/Navbar';

export const metadata = {
	title: 'Rum River Barn | Wedding Venue',
	description: 'Experience your dream wedding at Rum River Barn, a romantic venue in Minnesota',
};

/*
 * DEV SERVER: http://localhost:6666
 * CLEAN ARCHITECTURE: All components migrated to clean tokenized system
 * - All sections use clean design tokens and components
 * - Responsive design with semantic styling
 */

export default function RootLayout({ children }) {
	return (
		<StoryblokProvider>
			<html
				lang="en"
				className={`${playfairDisplay.variable} ${montserrat.variable} ${dancingScript.variable}`}
				suppressHydrationWarning
			>
				<head>
					<script
						dangerouslySetInnerHTML={{
							__html: `
(function(){
  try{
    var d = document.documentElement;

    // Theme (light/dark)
    var theme = localStorage.getItem('rr.theme');
    if(!theme){
      theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    d.setAttribute('data-theme', theme);

    // Brand (romantic/modern) - default to romantic for public site
    var brand = localStorage.getItem('rr.brand') || 'romantic';
    d.setAttribute('data-brand', brand);
  }catch(e){}
})();
`}}
					/>
				</head>
				<body>
					<ThemeProvider>
						<div data-clean-root="true">
							<Navbar />
							{children}
						</div>
					</ThemeProvider>
				</body>
			</html>
		</StoryblokProvider>
	);
}
