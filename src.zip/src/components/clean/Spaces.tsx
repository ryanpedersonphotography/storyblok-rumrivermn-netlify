'use client'

import React, { useState } from 'react'
import { storyblokEditable } from '@storyblok/react/rsc'
import type { SbBlokData } from '@storyblok/react/rsc'
import SpacesLayout from '@/components/layouts/SpacesLayout'

interface VenueFeatureStoryblok {
  label?: string
  value?: string
}

interface VenueStoryblok {
  title?: string
  images?: Array<{ filename?: string; alt?: string }>
  description?: string
  features?: VenueFeatureStoryblok[]
}

interface SpacesStoryblok extends SbBlokData {
  title?: string
  subtitle?: string
  script_accent?: string
  description?: string
  background_variant?: 'surface' | 'tint-rose' | 'tint-sage' | 'dark-gradient'
  theme_override?: 'auto' | 'light' | 'dark'
  padding_size?: 'sm' | 'md' | 'lg' | 'xl'
  barn?: VenueStoryblok
  bridal?: VenueStoryblok
  groom?: VenueStoryblok
  pavilion?: VenueStoryblok
}

export default function Spaces({ blok }: { blok: SpacesStoryblok }) {
  console.log('[Spaces] Rendering with blok:', blok)
  const [activeVenue, setActiveVenue] = useState('barn')
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const defaultVenueData = {
    barn: {
      title: 'The Historic Barn',
      images: [
        '/images/barn-exterior-full-deck-view-evening.jpg',
        '/images/real-weddings/anthony-and-linnea/photos/001.jpg',
        '/images/real-weddings/kyle-carrie/photos/015.jpg'
      ],
      description: 'Our crown jewel, this beautifully restored barn features soaring ceilings, original timber beams, and modern amenities seamlessly integrated into its historic charm.',
      features: [
        { label: 'Capacity', value: 'Up to 300 guests' },
        { label: 'Built', value: '1920s architecture' },
        { label: 'Features', value: 'Climate controlled' },
        { label: 'Style', value: 'Rustic elegance' }
      ]
    },
    bridal: {
      title: 'Bridal Suite',
      images: [
        '/images/real-weddings/emily-and-barron-nixon/photos/020.jpg',
        '/images/real-weddings/mattea-courtney-photo-gallery/photos/015.jpg'
      ],
      description: 'A luxurious private space for the bride and bridal party to prepare for the big day.',
      features: [
        { label: 'Capacity', value: 'Up to 8 people' },
        { label: 'Amenities', value: 'Full mirror, seating' },
        { label: 'Natural Light', value: 'Large windows' },
        { label: 'Privacy', value: 'Separate entrance' }
      ]
    },
    groom: {
      title: "Groom's Quarters",
      images: [
        '/images/real-weddings/joshua-and-teri/photos/008.jpg',
        '/images/real-weddings/anthony-and-linnea/photos/025.jpg'
      ],
      description: 'A comfortable retreat for the groom and groomsmen.',
      features: [
        { label: 'Capacity', value: 'Up to 6 people' },
        { label: 'Atmosphere', value: 'Relaxed and private' },
        { label: 'Amenities', value: 'Comfortable seating' },
        { label: 'Access', value: 'Separate entrance' }
      ]
    },
    pavilion: {
      title: 'Garden Pavilion',
      images: [
        '/images/real-weddings/loria-and-jason-rolstad-agape/photos/010.jpg',
        '/images/real-weddings/kyle-carrie/photos/040.jpg'
      ],
      description: 'An enchanting outdoor space perfect for ceremonies or cocktail hours.',
      features: [
        { label: 'Setting', value: 'Outdoor garden' },
        { label: 'Use', value: 'Ceremonies, cocktails' },
        { label: 'Atmosphere', value: 'Natural beauty' },
        { label: 'Capacity', value: 'Up to 200 guests' }
      ]
    }
  }

  // Merge Storyblok data with defaults
  const venueData = {
    barn: blok.barn || defaultVenueData.barn,
    bridal: blok.bridal || defaultVenueData.bridal,
    groom: blok.groom || defaultVenueData.groom,
    pavilion: blok.pavilion || defaultVenueData.pavilion
  }

  // Convert Storyblok image format to simple string array for compatibility
  const getVenueImages = (venue: VenueStoryblok | typeof defaultVenueData.barn) => {
    if ('images' in venue && Array.isArray(venue.images)) {
      if (venue.images.length > 0 && typeof venue.images[0] === 'object' && 'filename' in venue.images[0]) {
        // Storyblok format
        return venue.images.map(img => img.filename || '')
      }
    }
    // Default format (already strings)
    return venue.images as string[]
  }

  const title = blok.title || 'Discover Our Spaces'
  const subtitle = blok.script_accent || blok.subtitle || 'Your Perfect Setting'
  const description = blok.description || 'Every corner tells a story, every space creates memories'
  
  // Get background and theme from Storyblok or use defaults
  const backgroundVariant = blok.background_variant || 'tint-rose'
  const themeOverride = blok.theme_override || 'auto'
  const paddingSize = blok.padding_size || 'lg'

  const handleVenueChange = (venue: string) => {
    setActiveVenue(venue)
    setCurrentImageIndex(0)
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) =>
      (prev + 1) % venueData[activeVenue as keyof typeof venueData].images.length
    )
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) =>
      prev === 0 ? venueData[activeVenue as keyof typeof venueData].images.length - 1 : prev - 1
    )
  }

  return (
    <SpacesLayout
      {...storyblokEditable(blok)}
      header={{
        scriptAccent: subtitle,
        title: title,
        lead: description
      }}
      // Use Storyblok-configured styling
      background={backgroundVariant}
      tone={themeOverride}
      paddingY={paddingSize}
      divider="none"          // Clean transition
      useContentWrapper={true} // Consistent width
      data-discover="true"
      data-section="spaces"
    >
      <div className="venue-tabs">
        {Object.entries(venueData).map(([key, venue]) => (
          <button
            key={key}
            className={`venue-tab ${activeVenue === key ? 'active' : ''}`}
            onClick={() => handleVenueChange(key)}
          >
            {venue.title}
          </button>
        ))}
      </div>

      <div className="spaces-content layout-classic">
          <div className="venue-main-image">
            <img
              src={getVenueImages(venueData[activeVenue as keyof typeof venueData])[currentImageIndex]}
              alt={venueData[activeVenue as keyof typeof venueData].title}
            />
            <button className="carousel-arrow prev" onClick={prevImage}>←</button>
            <button className="carousel-arrow next" onClick={nextImage}>→</button>
          </div>

          <div className="venue-details">
            <h3>{venueData[activeVenue as keyof typeof venueData].title}</h3>
            <p>{venueData[activeVenue as keyof typeof venueData].description}</p>
            <div className="venue-features">
              {venueData[activeVenue as keyof typeof venueData].features.map((feature, index) => (
                <div key={index} className="venue-feature">
                  <h5>{feature.label}</h5>
                  <p>{feature.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
    </SpacesLayout>
  )
}
